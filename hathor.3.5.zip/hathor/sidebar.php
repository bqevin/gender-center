<div id="sidebar">
    <div class="widgets">          
            <?php if ( is_active_sidebar('dynamic_sidebar') || !dynamic_sidebar('Right Sidebar') ) : ?> 
            <?php endif; ?>
            </div>
    </div>