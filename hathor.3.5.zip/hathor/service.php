<!--MIDROW STARTS-->

<div class="midrow">

 <div class="midrow_wrap">  
 <?php if ( of_get_option('block1_text') ) { ?>     
        <div class="midrow_blocks">  
       
        <div class="midrow_blocks_wrap">
        <div class="icon_warp">
        <?php  if(of_get_option('block1_image')) { ?>  
        <img  src="<?php echo of_get_option('block1_image'); ?>"  />
        <?php } ?></div>
        
        <div class="midrow_block">
        <div class="mid_block_content">
        <h3><?php echo of_get_option('block1_text'); ?></h3>
        <p><?php echo of_get_option('block1_textarea'); ?></p>
    
        </div>
        <div class="link">
         <?php if ( of_get_option('block1_link') ) { ?><a href="<?php echo of_get_option('block1_link'); ?>" class="midbutton"><?php echo of_get_option('servicelink2'); ?></a><?php } ?></div>
        </div>
        
        
        </div>
        
       
        </div>
        
        
         
        <?php } ?>
        
         <?php if ( of_get_option('block2_text') ) { ?>
         <div class="midrow_blocks">  
        
       <div class="midrow_blocks_wrap">
        <div class="icon_warp">
          <?php  if(of_get_option('block2_image')) { ?>  
         <img  src="<?php echo of_get_option('block2_image'); ?>"  />
         <?php } ?>
         </div>
        
        
        <div class="midrow_block">
        
        <div class="mid_block_content">
        <h3><?php echo of_get_option('block2_text'); ?></h3>
        <p><?php echo of_get_option('block2_textarea'); ?></p>
    
        </div>
        <div class="link">
          <?php if ( of_get_option('block2_link') ) { ?><a  href="<?php echo of_get_option('block2_link'); ?>" class="midbutton"><?php echo of_get_option('servicelink2'); ?></a><?php } ?></div>
        </div></div>
        
        
        </div>
         <?php } ?>
         
        
        <?php if ( of_get_option('block3_text') ) { ?>
         <div class="midrow_blocks">  
        
       <div class="midrow_blocks_wrap">
        <div class="icon_warp">
         <?php  if(of_get_option('block3_image')) { ?>  
         <img  src="<?php echo of_get_option('block3_image'); ?>"  />
         <?php } ?>
         </div>
        
        
        <div class="midrow_block">
        
        <div class="mid_block_content">
        <h3><?php echo of_get_option('block3_text'); ?></h3>
        <p><?php echo of_get_option('block3_textarea'); ?></p>
    
        </div>
        <div class="link">
          <?php if ( of_get_option('block3_link') ) { ?><a  href="<?php echo of_get_option('block3_link'); ?>" class="midbutton"><?php echo of_get_option('servicelink2'); ?></a><?php } ?></div>
        </div></div>
        
        
        </div>
         <?php } ?>
         
         
       <?php if ( of_get_option('block4_text') ) { ?>
         <div class="midrow_blocks">  
        
       <div class="midrow_blocks_wrap">
      <div class="icon_warp">
       <?php  if(of_get_option('block4_image')) { ?> 
      <img  src="<?php echo of_get_option('block4_image'); ?>" />
      <?php } ?>
       </div>
        
        
        <div class="midrow_block">
        
        <div class="mid_block_content">
        <h3><?php echo of_get_option('block4_text'); ?></h3>
        <p><?php echo of_get_option('block4_textarea'); ?></p>
    
        </div>
        <div class="link">
          <?php if ( of_get_option('block4_link') ) { ?><a  href="<?php echo of_get_option('block4_link'); ?>" class="midbutton"><?php echo of_get_option('servicelink2'); ?></a><?php } ?></div>
        </div></div>
      
        
        </div>
         <?php } ?>
        



 
         
        </div>
        
        
        </div>
     </div>   
</div>
 
        
   



<!--MIDROW END-->
  
        
             
          
     

   

</div>