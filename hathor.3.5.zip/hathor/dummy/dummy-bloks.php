<!--MIDROW STARTS-->

<div class="midrow">

 <div class="midrow_wrap">  
   
        <div class="midrow_blocks">  
       
        <div class="midrow_blocks_wrap">
        <div class="icon_warp">
         
        <img  src="<?php echo get_template_directory_uri(); ?>/images/demo/slide1.jpg"  />
       </div>
        
        <div class="midrow_block">
        <div class="mid_block_content">
         <h3>We Work Efficiently</h3>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam nec rhoncus risus. In ultrices lacinia ipsum, posuere faucibus velit bibendum ac.</p>
    
        </div>
       <a style="margin-left:26%" href="#" class="midbutton">show me details</a>
        </div>
        
        
        </div>
        
       
        </div>
        
        
         
        
         
         <div class="midrow_wrap">  
   
        <div class="midrow_blocks">  
       
        <div class="midrow_blocks_wrap">
        <div class="icon_warp">
         
        <img  src="<?php echo get_template_directory_uri(); ?>/images/2.jpg"  />
       </div>
        
        <div class="midrow_block">
        <div class="mid_block_content">
         <h3>We Work Efficiently</h3>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam nec rhoncus risus. In ultrices lacinia ipsum, posuere faucibus velit bibendum ac.</p>
    
        </div>
       <a style="margin-left:26%" href="#" class="midbutton">show me details</a>
        </div>
        
        
        </div>
        
       
        </div>
         
         
        
        <div class="midrow_wrap">  
   
        <div class="midrow_blocks">  
       
        <div class="midrow_blocks_wrap">
        <div class="icon_warp">
         
        <img  src="<?php echo get_template_directory_uri(); ?>/images/3.jpg"  />
       </div>
        
        <div class="midrow_block">
        <div class="mid_block_content">
         <h3>We Work Efficiently</h3>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam nec rhoncus risus. In ultrices lacinia ipsum, posuere faucibus velit bibendum ac.</p>
    
        </div>
       <a style="margin-left:26%" href="#" class="midbutton">show me details</a>
        </div>
        
        
        </div>
        
       
        </div>
         
        <div class="midrow_wrap">  
   
        <div class="midrow_blocks">  
       
        <div class="midrow_blocks_wrap">
        <div class="icon_warp">
         
        <img  src="<?php echo get_template_directory_uri(); ?>/images/walking.jpg"  />
       </div>
        
        <div class="midrow_block">
        <div class="mid_block_content">
         <h3>We Work Efficiently</h3>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam nec rhoncus risus. In ultrices lacinia ipsum, posuere faucibus velit bibendum ac.</p>
    
        </div>
       <a style="margin-left:26%" href="#" class="midbutton">show me details</a>
        </div>
        
        
        </div>
        
       
        </div>
        
        
        
        



 
         
        </div>
        
        
        </div>
     </div>   
</div>
 
        
   



<!--MIDROW END-->
  
        
             
          
     

   

</div>