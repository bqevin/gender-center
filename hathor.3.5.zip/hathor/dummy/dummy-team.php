


<div class="our_team">
        <div class="title">
          <h2 class="blue1">Our Team</h2>
          <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy</p>
        </div>
        <div id="middle" class="cols2 sidebar_left box_white">
          <div class="content" role="main">
            <article class="post-detail">
              <div class="entry">
                <div class="work-carousel">
                  <div class="work-carousel-head"> <a class="prev" id="work-carousel-prev3" href="#" ><span>prev</span></a> <a class="next" id="work-carousel-next3" href="#"><span>next</span></a> </div>
                  <div class="carousel_content">
                    <div class="caroufredsel_wrapper" >
                      <ul id="work-carousel3" >
                        <li>
                        
                          <div class="work">
                            <div class="main">
                           
                            
                              <div class="view_team view-fifth"> <img  src="<?php echo get_template_directory_uri(); ?>/images/demo/team1.png" alt="<?php echo of_get_option('ourteamtitle1'); ?>" />
                            <a href="#" >
                                <div class="mask">
                                
                               
                                  <h2>Mr.ronty</h2>
                                  
                                  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy</p>
                                   </div>
                                   </a>
                              </div>
                            </div>
                            <p class="port_team"><a href="#">Mr.ronty</a></p>
                          </div>
                        </li>
                       <li>
                        
                          <div class="work">
                            <div class="main">
                           
                            
                              <div class="view_team view-fifth"> <img  src="<?php echo get_template_directory_uri(); ?>/images/demo/team2.png" alt="<?php echo of_get_option('ourteamtitle1'); ?>" />
                            <a href="#" >
                                <div class="mask">
                                
                               
                                  <h2>Mr.jonty</h2>
                                  
                                  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy</p>
                                   </div>
                                   </a>
                              </div>
                            </div>
                            <p class="port_team"><a href="#">Mr.jonty</a></p>
                          </div>
                        </li>
                        <li>
                        
                          <div class="work">
                            <div class="main">
                           
                            
                              <div class="view_team view-fifth"> <img  src="<?php echo get_template_directory_uri(); ?>/images/demo/team3.png" alt="<?php echo of_get_option('ourteamtitle1'); ?>" />
                            <a href="#" >
                                <div class="mask">
                                
                               
                                  <h2>Mrs.olay</h2>
                                  
                                  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy</p>
                                   </div>
                                   </a>
                              </div>
                            </div>
                            <p class="port_team"><a href="#">Mrs.olay</a></p>
                          </div>
                        </li>
                        <li>
                        
                          <div class="work">
                            <div class="main">
                           
                            
                              <div class="view_team view-fifth"> <img  src="<?php echo get_template_directory_uri(); ?>/images/demo/team1.png" alt="<?php echo of_get_option('ourteamtitle1'); ?>" />
                            <a href="#" >
                                <div class="mask">
                                
                               
                                  <h2>Mr.imon</h2>
                                  
                                  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy</p>
                                   </div>
                                   </a>
                              </div>
                            </div>
                            <p class="port_team"><a href="#">Mr.imon</a></p>
                          </div>
                        </li>
                       
                        
                        
                       
                    
                         
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </article>
            </div></div>