<div class="row"> 
         
 <div id="nivo" >
                
                
                
                <img title="#nv_1" src="<?php echo get_template_directory_uri(); ?>/images/demo/slide1.jpg"  alt="" data-transition="slideInLeft" />
				
                
              
            
      </div>
      </div>     