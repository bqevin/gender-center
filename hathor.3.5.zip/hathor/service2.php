<!--MIDROW STARTS-->

<div class="style2 midrow">

 <div class="style2 midrow_wrap">  
 <?php if ( of_get_option('block1_text') ) { ?>     
        <div class="style2 midrow_blocks">  
       
        <div class="style2 midrow_blocks_wrap"> 
        <div class="style2 icon_warp">
        
        <div class=" style2 icon_img "><i class="fa <?php echo of_get_option('block1_logo'); ?> fa-3x icon"></i> </div></div>
        
        <div class="style2 midrow_block">
        <div class="style2 mid_block_content">
        <h3><?php echo of_get_option('block1_text'); ?></h3>
        <p><?php echo of_get_option('block1_textarea'); ?></p>
    
        </div>
        <div class="link">
         <?php if ( of_get_option('block1_link') ) { ?><a href="<?php echo of_get_option('block1_link'); ?>" class="midbutton"><?php echo of_get_option('servicelink2'); ?></a><?php } ?></div>
        </div>
        
        
        </div>
        
       
        </div>
        
        
         
        <?php } ?>
          <?php if ( of_get_option('block2_text') ) { ?>  
        <div class="style2 midrow_blocks">  
        
       <div class=" style2 midrow_blocks_wrap">
       <div class="style2 icon_warp">
       <div class="style2 icon_img "> <i class="fa <?php echo of_get_option('block2_logo'); ?> fa-3x icon"></i></div></div>
        
        <div class="style2 midrow_block">
        
        <div class="style2 mid_block_content">
        <h3><?php echo of_get_option('block2_text'); ?></h3>
        <p><?php echo of_get_option('block2_textarea'); ?></p>
     
        </div>
        <div class="link">
        <?php if ( of_get_option('block2_link') ) { ?><a href="<?php echo of_get_option('block2_link'); ?>" class="midbutton"><?php echo of_get_option('servicelink2'); ?></a><?php } ?></div>
        </div></div>
        
        
        </div>
        <?php } ?>
        
        <?php if ( of_get_option('block3_text') ) { ?>
         <div class="style2 midrow_blocks">  
        
       <div class="style2 midrow_blocks_wrap">
        <div class="style2 icon_warp"><div class=" style2 icon_img "><i class="fa <?php echo of_get_option('block3_logo'); ?> fa-3x icon"></i></div></div>
        
        
        <div class="style2 midrow_block">
        
        <div class="style2 mid_block_content">
        <h3><?php echo of_get_option('block3_text'); ?></h3>
        <p><?php echo of_get_option('block3_textarea'); ?></p>
    
        </div>
        <div class="link">
          <?php if ( of_get_option('block3_link') ) { ?><a href="<?php echo of_get_option('block3_link'); ?>" class="midbutton"><?php echo of_get_option('servicelink2'); ?></a><?php } ?></div>
        </div></div>
        
        
        </div>
         <?php } ?>
         
         
       <?php if ( of_get_option('block4_text') ) { ?>
         <div class="style2 midrow_blocks">  
        
       <div class="style2 midrow_blocks_wrap">
      <div class="style2 icon_warp"> <div class="style2 icon_img "> <i class="fa <?php echo of_get_option('block4_logo'); ?> fa-3x icon"></i></div></div>
        
        
        <div class="style2 midrow_block">
        
        <div class="style2 mid_block_content">
        <h3><?php echo of_get_option('block4_text'); ?></h3>
        <p><?php echo of_get_option('block4_textarea'); ?></p>
    
        </div>
        <div class="link">
          <?php if ( of_get_option('block4_link') ) { ?><a href="<?php echo of_get_option('block4_link'); ?>" class="midbutton"><?php echo of_get_option('servicelink2'); ?></a><?php } ?></div>
        </div></div>
      
        
        </div>
         <?php } ?>
        



 
         
        </div>
        
        
        </div>
     </div>   
</div>
 
        
   



<!--MIDROW END-->
  
        
             
          
     

   

</div>